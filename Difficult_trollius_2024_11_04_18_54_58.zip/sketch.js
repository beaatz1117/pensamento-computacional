let campoIdade;
let campoFantasia;
let campoAventura;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("12");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
}

function draw() {
  background("white");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 12) {
    if (idade >= 14) {
      return "queen of tears";
    } else {
      if (idade >= 16) {
        if(gostaDeFantasia || gostaDeAventura) {
          return "the k2";          
        } else{
         return "bloodhounds";
        }
      } else {
        if (gostaDeFantasia) {
          return "twinkling watermelon";
        } else {
          return "advogado por um dólar";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "bad and crazy";
    } else {
      return "doom at your service";
    }
  }
}
